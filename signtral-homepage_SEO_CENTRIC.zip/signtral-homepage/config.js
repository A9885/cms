/*
  Update these routes to match your existing pages.
  Keep all files in the same folder if you want simple local linking.
*/
window.SIGNTRAL_ROUTES = {
  login: "login.html",
  advertiserPortal: "advertiser-dashboard.html",
  partnerDashboard: "partner-dashboard.html",
  getStarted: "#contact",
  partnerWithUs: "#contact"
};

/*
  Update this email address if you want the enquiry form to open a different mailbox.
*/
window.SIGNTRAL_CONTACT_EMAIL = "hello@signtral.in";
