SIGNTRAL HOMEPAGE FILES
=======================

Files included:
- index.html
- styles.css
- script.js
- config.js
- assets/logo-mark.svg

How to use:
1. Keep all files and the assets folder together in one directory.
2. Open config.js and replace the sample file names with your actual page names.
3. Double-click index.html or open it in any browser.

Notes:
- This page works as a local static file.
- No build tools are required.
- If you want it fully offline, remove the Google Fonts link in index.html or replace it with a local font setup.
