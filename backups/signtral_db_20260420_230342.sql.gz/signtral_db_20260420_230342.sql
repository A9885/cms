-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: signtralDB
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(255) NOT NULL,
  `userId` varchar(255) NOT NULL,
  `accountId` varchar(255) NOT NULL,
  `providerId` varchar(255) NOT NULL,
  `password` text,
  `accessToken` text,
  `refreshToken` text,
  `idToken` text,
  `expiresAt` datetime DEFAULT NULL,
  `passwordExpiresAt` datetime DEFAULT NULL,
  `scope` text,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `account_ibfk_1` (`userId`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('17u3nfi76he','user_e7dab160e50e00846c281c8c','admin','credential','9fa6ffe6ff60070be57726bde442758d:2bc0b2e65fef0344284bc55c42e66113a128e2174229272c0e5aecaab9f9d7028b2a500bc6eed00c90301c5028181d2300a6d4acfe906f8ca61a5f3b993625db',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 21:13:26','2026-04-18 21:13:26'),('2TH73OcDqcuSZ9pJXrUxOymYI4P8Sew3','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','credential','0cc3d5c826d8c9194a3d2bc41874e46b:7a936c914b6ce18ce44e14731273d8e42486fbc183238d12f79655d50a5745ecd6c506d4984c598f2c343e192ea855bc45df9f1f655807be533e71d2eb0d9c1c',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-20 15:25:19','2026-04-20 15:25:19'),('acc_29c4ad5678edf6aa206bbd6f','user_ed5c13476458e276304adaf2','test@gmail.com','credential','4b32fc8a35e55e944424806b2f6b2060:620372075f63df357cbfba72662798ce522735fbd77763e5f30f7d836ad40c1ed5a932f9711de4291a30c395e5079bba8466da81c43c40c015c86b8f4cd2325a',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 16:44:51','2026-04-18 16:44:51'),('acc_3db1a7acfab0a35ff6ccf0a9','user_ed5c13476458e276304adaf2','test@gmail.com','credential','5e120c830c3b1feb8d380d1e50deb528:d24f3efebf8bc5acb19c07b2fe97b9f3f56bb14e122e0f68419b7a0b6f9a1d8431b0988918411872a0a37842f582adc7461842598d63bbb4ce1b41721aa781f3',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 16:27:47','2026-04-18 16:28:16'),('acc_40703be97d5d86a54939806e','user_ed5c13476458e276304adaf2','test@gmail.com','credential','6d570c41ce87dd889557fea2f99f4dd7:f9c7cfce30168f5a93d212132abe0e0abac0fe20f123d8a42a9a4f9ff3c7e60ec417b38abae0084cf1ff205990266ea2db64f46f742c497bc250200edd4e3df1',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 16:44:24','2026-04-18 16:44:24'),('acc_67f99cc731261cd974517398','user_ed5c13476458e276304adaf2','test@gmail.com','credential','5e120c830c3b1feb8d380d1e50deb528:d24f3efebf8bc5acb19c07b2fe97b9f3f56bb14e122e0f68419b7a0b6f9a1d8431b0988918411872a0a37842f582adc7461842598d63bbb4ce1b41721aa781f3',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 16:27:39','2026-04-18 16:28:16'),('acc_c7d1c272d67b3a1eef9e0f37','user_e7dab160e50e00846c281c8c','admin@signtral.com','credential','8406ee5d4e3c71a1eb2d50b6a522a756:4323ff0e751684c6dd5fe15d9fa97d25ad60baa2f59a45d816f97446fa96e7161102acb2a540a83205c4a9de44c13a6a926cbf6adf8e0d8d97fc39c016703392',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 21:13:24','2026-04-18 21:13:24'),('acc_user_10a539f695c89197a048b827','user_10a539f695c89197a048b827','test@test.com','credential','250a89e19ac111b72ba539a07a20b18a:a8b8ec32df669017a0b89476be04f9b8d51c10c19acc5648da7e12593e34db2cd90d212f6767517e7445105be921d7a86c7f3a7e1322759747a978934dfba309',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 21:20:58','2026-04-19 12:12:29'),('ds8eg949j2p','user_e7dab160e50e00846c281c8c','admin','credential','4990fa3fb4c13ee56af47b144a886ad2:16a075bd7a8cdded4fb42e42f217ba5f1a0ea0e5c4525e8971e14df1c3fe8078572ea4bbe414108f3071730a72cfa60f7df11afea7f6e3a54bbde07a360952f9',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-18 21:13:26','2026-04-18 21:13:26'),('RtshoyJoLGuijQof8BnFrvry0D3Ch1zR','gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','credential','8539c911016ba47fbd55a9c43a4163c6:459e34d823a071d9b230062f00d624611b9b4996a1babfa212e0e15f80b26a44ef462b3bd082885b28157bec8be4a6058f15d2f8f038609d0d67257381823934',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-20 22:12:42','2026-04-20 22:12:42'),('UgqwEsc97ryBIQKLUc2HNTTCbQpNq4nv','3aWsjPSEhfh9GZDlYooNUImsJaKQcYg8','3aWsjPSEhfh9GZDlYooNUImsJaKQcYg8','credential','7d3fbce03a61f7728b76a841a39c8797:3e2da0e14abdc5629051ea7217739fda6f47ee0e57b1f8e3df32b958f92d7b8700f39fe4e639eda8bdf89d0b2bd88cee8af718556689ddaf2cdde6d457048786',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-20 15:35:08','2026-04-20 15:35:08');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_module` (`module`),
  KEY `idx_action` (`action`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,NULL,'LOGIN','AUTH','Failed login attempt for \"admin\"','::1','2026-04-17 07:06:15'),(2,NULL,'LOGIN','AUTH','Failed login attempt for \"admin\"','::1','2026-04-17 07:07:33'),(3,NULL,'LOGIN','AUTH','Failed login attempt for \"admin\"','::1','2026-04-17 07:10:06'),(4,NULL,'LOGIN','AUTH','Failed login attempt for \"admin@signtral.com\"','::1','2026-04-17 07:10:14'),(5,'1','ERROR','BRAND','Failed to create brand \"test\": Field \'id\' doesn\'t have a default value','::ffff:127.0.0.1','2026-04-18 10:59:26'),(6,'1','ERROR','BRAND','Failed to create brand \"test\": Field \'id\' doesn\'t have a default value','::ffff:127.0.0.1','2026-04-18 10:59:39'),(7,'1','CREATE','BILLING','Subscription created for Brand ID 2 (Plan: test)','::ffff:127.0.0.1','2026-04-18 11:00:25'),(8,'1','ASSIGN','SLOT','Slot 1 on Display 3 assigned to Brand ID 2','::ffff:127.0.0.1','2026-04-18 11:00:30'),(9,'1','ASSIGN','CREATIVE','Media ID 1 manually assigned to Brand ID 2','::ffff:127.0.0.1','2026-04-18 11:00:44'),(10,'1','ERROR','PARTNER','Failed to create partner \"Anjan Kumar\": Field \'id\' doesn\'t have a default value','::1','2026-04-18 11:01:48'),(11,'1','ERROR','PARTNER','Failed to create partner \"Live Test 1\": Field \'id\' doesn\'t have a default value','::ffff:127.0.0.1','2026-04-18 11:24:00'),(12,'1','ERROR','BRAND','Failed to create brand \"Live Test Brand\": Field \'id\' doesn\'t have a default value','::1','2026-04-18 11:26:01'),(13,'1','LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 11:34:41'),(14,'1','ASSIGN','CREATIVE','Media ID 4 manually assigned to Brand ID 2','::1','2026-04-18 12:55:56'),(15,'1','LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 12:56:29'),(16,'1','LOGOUT','AUTH','User \"admin\" logged out','152.59.198.12','2026-04-18 12:57:37'),(17,'1','ERROR','BRAND','Failed to create brand \"New Test Brand\": Field \'password\' doesn\'t have a default value','::1','2026-04-18 14:23:01'),(18,'1','LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-18 14:27:15'),(19,'1','LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 14:34:02'),(20,'1','LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 14:43:58'),(21,'1','UPDATE','BILLING','Subscription ID 1 updated','::1','2026-04-18 14:46:17'),(22,'1','ASSIGN','SLOT','Slot 3 on Display 3 assigned to Brand ID 2','::1','2026-04-18 14:46:20'),(23,'1','ERROR','BRAND','Failed to create brand \"New Test Brand\": Field \'password\' doesn\'t have a default value','::1','2026-04-18 14:46:21'),(24,'1','LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 14:46:26'),(25,'1','LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-18 15:28:44'),(26,'1','LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-18 15:28:57'),(27,'1','LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-18 15:33:49'),(28,'1','ERROR','BRAND','Failed to create brand \"test\": Field \'password\' doesn\'t have a default value','::ffff:127.0.0.1','2026-04-18 15:39:41'),(29,'1','ERROR','BRAND','Failed to create brand \"Brand A\": Field \'password\' doesn\'t have a default value','::ffff:127.0.0.1','2026-04-18 16:11:14'),(30,'1','UPDATE','BRAND','Brand ID 7 updated','::1','2026-04-18 16:27:39'),(31,'1','UPDATE','BRAND','Brand ID 7 updated','::1','2026-04-18 16:27:47'),(32,'1','UPDATE','BRAND','Brand ID 7 updated','::1','2026-04-18 16:44:24'),(33,'1','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-18 16:44:51'),(34,'1','CREATE','BILLING','Subscription created for Brand ID 7 (Plan: test)','::1','2026-04-18 16:45:21'),(35,'1','ASSIGN','SLOT','Slot 1 on Display 3 assigned to Brand ID 7','::ffff:127.0.0.1','2026-04-18 16:45:30'),(36,'1','ASSIGN','SLOT','Slot 2 on Display 3 assigned to Brand ID 7','::1','2026-04-18 16:45:30'),(37,'1','DELETE','PARTNER','Partner \"Live Test 1\" (ID: 2) deleted','::1','2026-04-18 17:31:41'),(38,'1','SYNC','PARTNER','Partner ID 1 screens updated (Count: 1)','::1','2026-04-18 17:31:49'),(39,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 1 manually assigned to Brand ID 7','::1','2026-04-18 21:20:00'),(40,'user_e7dab160e50e00846c281c8c','UPDATE','PARTNER','Partner ID 1 updated','::ffff:127.0.0.1','2026-04-18 21:20:58'),(41,'user_e7dab160e50e00846c281c8c','SYNC','PARTNER','Partner ID 1 screens updated (Count: 0)','::1','2026-04-18 21:21:12'),(42,'user_e7dab160e50e00846c281c8c','SYNC','PARTNER','Partner ID 1 screens updated (Count: 1)','::ffff:127.0.0.1','2026-04-18 21:21:19'),(43,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 21:25:07'),(44,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 2 on Display 3 (mediaId: 24)','::1','2026-04-18 21:30:42'),(45,'user_e7dab160e50e00846c281c8c','DELETE','SLOT','Media (widget: 118) removed from Slot 3 on Display 3','::1','2026-04-18 21:37:26'),(46,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 3 on Display 3 (mediaId: 25)','::1','2026-04-18 21:37:34'),(47,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 25 linked to Brand ID 7 on Display 3','::ffff:127.0.0.1','2026-04-18 21:37:37'),(48,'user_e7dab160e50e00846c281c8c','DELETE','SLOT','Media (widget: 123) removed from Slot 4 on Display 3','::ffff:127.0.0.1','2026-04-18 21:39:35'),(49,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 4 on Display 3 (mediaId: 26)','::ffff:127.0.0.1','2026-04-18 21:39:45'),(50,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 26 linked to Brand ID 7 on Display 3','::ffff:127.0.0.1','2026-04-18 21:39:47'),(51,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-18 22:07:03'),(52,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-18 22:37:26'),(53,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 3 on Display 3 unassigned','::1','2026-04-19 11:24:25'),(54,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 1 on Display 3 unassigned','::ffff:127.0.0.1','2026-04-19 11:24:40'),(55,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 1 on Display 3 assigned to Brand ID 7','::ffff:127.0.0.1','2026-04-19 11:24:48'),(56,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 1 on Display 3 unassigned','::1','2026-04-19 11:25:36'),(57,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 3 on Display 3 assigned to Brand ID 7','::1','2026-04-19 11:25:37'),(58,'user_e7dab160e50e00846c281c8c','DELETE','SLOT','Media (widget: 120) removed from Slot 1 on Display 3','::ffff:127.0.0.1','2026-04-19 11:25:52'),(59,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 1 updated','::ffff:127.0.0.1','2026-04-19 11:27:27'),(60,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-19 11:42:44'),(61,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-19 11:43:50'),(62,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-19 11:49:19'),(63,NULL,'LOGOUT','AUTH','User \"test@gmail.com\" logged out','::1','2026-04-19 11:49:31'),(64,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-19 11:54:07'),(65,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::ffff:127.0.0.1','2026-04-19 12:02:34'),(66,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::1','2026-04-19 12:03:16'),(67,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 7 updated','::1','2026-04-19 12:09:30'),(68,'user_e7dab160e50e00846c281c8c','UPDATE','PARTNER','Partner ID 1 updated','::ffff:127.0.0.1','2026-04-19 12:12:29'),(69,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"screen 01\" (ID: 1) deleted','::ffff:127.0.0.1','2026-04-19 18:04:07'),(70,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"screen 01\" (ID: 2) deleted','::1','2026-04-19 18:04:12'),(71,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Screen \"Screen 2\" added (ID: 4)','::1','2026-04-19 18:04:56'),(72,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"screen 01\" (ID: 3) deleted','::ffff:127.0.0.1','2026-04-19 18:05:00'),(73,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"screen 01\" (ID: 5) deleted','::ffff:127.0.0.1','2026-04-19 18:08:00'),(74,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"Screen 2\" (ID: 4) deleted','::1','2026-04-19 18:08:09'),(75,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 7) deleted','::ffff:127.0.0.1','2026-04-19 18:08:20'),(76,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 6 updated','::ffff:127.0.0.1','2026-04-19 18:08:59'),(77,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 6 updated','::1','2026-04-19 18:09:12'),(78,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 8) deleted','::1','2026-04-19 18:09:16'),(79,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 9) deleted','::1','2026-04-19 18:09:25'),(80,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 10) deleted','::ffff:127.0.0.1','2026-04-19 18:09:37'),(81,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH\" (ID: 6) deleted','::ffff:127.0.0.1','2026-04-19 18:09:44'),(82,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Screen \"screen 1\" added (ID: 11)','::ffff:127.0.0.1','2026-04-19 18:10:32'),(83,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 12) deleted','::ffff:127.0.0.1','2026-04-19 18:11:36'),(84,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 13) deleted','::ffff:127.0.0.1','2026-04-19 18:11:41'),(85,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"screen 1\" (ID: 11) deleted','::ffff:127.0.0.1','2026-04-19 18:11:43'),(86,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 14) deleted','::ffff:127.0.0.1','2026-04-19 18:11:48'),(87,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 15) deleted','::ffff:127.0.0.1','2026-04-19 18:11:54'),(88,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"scrren\" registered via code (Xibo ID: undefined)','::ffff:127.0.0.1','2026-04-19 18:45:30'),(89,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"scc\" registered via code (Xibo ID: undefined)','::ffff:127.0.0.1','2026-04-19 18:46:02'),(90,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 16) deleted','::ffff:127.0.0.1','2026-04-19 18:46:34'),(91,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 18 updated','::1','2026-04-19 18:49:00'),(92,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569\" (ID: 18) deleted','::ffff:127.0.0.1','2026-04-19 18:49:12'),(93,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"CPH2569-unknown\" (ID: 17) deleted','::ffff:127.0.0.1','2026-04-19 18:49:15'),(94,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 2 on Display 6 (mediaId: 27)','::ffff:127.0.0.1','2026-04-19 18:49:27'),(95,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 27 linked to Brand ID 7 on Display 6','::ffff:127.0.0.1','2026-04-19 18:49:30'),(96,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 4 on Display 6 (mediaId: 28)','::1','2026-04-19 18:49:41'),(97,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 28 linked to Brand ID 7 on Display 6','::ffff:127.0.0.1','2026-04-19 18:49:43'),(98,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 19 updated','::ffff:127.0.0.1','2026-04-19 18:50:35'),(99,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 19 updated','::ffff:127.0.0.1','2026-04-19 18:50:40'),(100,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::1','2026-04-19 18:52:39'),(101,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 2 on Display 6 unassigned','::ffff:127.0.0.1','2026-04-19 18:55:28'),(102,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 4 on Display 6 unassigned','::ffff:127.0.0.1','2026-04-19 18:55:30'),(103,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"BrandB\": Failed to create user','::ffff:127.0.0.1','2026-04-19 18:56:08'),(104,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"BrandB\": Failed to create user','::1','2026-04-19 18:56:18'),(105,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand B\": Failed to create user','::ffff:127.0.0.1','2026-04-19 18:56:50'),(106,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand B\": Failed to create user','::1','2026-04-19 18:57:04'),(107,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand as\": Username is invalid','::ffff:127.0.0.1','2026-04-19 19:03:30'),(108,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand AB\": Username is invalid','::1','2026-04-19 19:06:18'),(109,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand A\": Failed to create brand account: User already exists. Use another email.','::ffff:127.0.0.1','2026-04-20 14:45:07'),(110,'user_e7dab160e50e00846c281c8c','ERROR','BRAND','Failed to create brand \"Brand A\": Failed to create brand account: Failed to create user','::1','2026-04-20 14:45:16'),(111,'user_e7dab160e50e00846c281c8c','SYNC','PARTNER','Partner ID 1 screens updated (Count: 1)','::1','2026-04-20 14:51:49'),(112,'user_e7dab160e50e00846c281c8c','LOGIN','AUTH','Admin impersonated Brand User: test@gmail.com (Brand ID: 1)','::1','2026-04-20 15:21:52'),(113,'user_e7dab160e50e00846c281c8c','CREATE','BILLING','Subscription created for Brand ID 1 (Plan: test)','::1','2026-04-20 15:23:31'),(114,'user_e7dab160e50e00846c281c8c','UPDATE','BILLING','Subscription ID 3 updated','::ffff:127.0.0.1','2026-04-20 15:23:58'),(115,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 13 on Display 6 assigned to Brand ID 1','::ffff:127.0.0.1','2026-04-20 15:24:05'),(116,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 1 on Display 6 assigned to Brand ID 1','::1','2026-04-20 15:24:05'),(117,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 13 on Display 6 unassigned','::1','2026-04-20 15:24:08'),(118,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 2 on Display 6 assigned to Brand ID 1','::1','2026-04-20 15:24:10'),(119,'user_e7dab160e50e00846c281c8c','CREATE','BRAND','Brand \"Brand A\" created (ID: 16)','::1','2026-04-20 15:25:18'),(120,'user_e7dab160e50e00846c281c8c','CREATE','BILLING','Subscription created for Brand ID 16 (Plan: test)','::1','2026-04-20 15:26:27'),(121,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 1 on Display 6 assigned to Brand ID 16','::1','2026-04-20 15:26:31'),(122,'user_e7dab160e50e00846c281c8c','UPDATE','BILLING','Subscription ID 4 updated','::ffff:127.0.0.1','2026-04-20 15:26:51'),(123,'user_e7dab160e50e00846c281c8c','UPDATE','BILLING','Subscription ID 4 updated','::1','2026-04-20 15:27:22'),(124,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 2 on Display 6 assigned to Brand ID 16','::ffff:127.0.0.1','2026-04-20 15:27:27'),(125,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 3 on Display 6 assigned to Brand ID 16','::ffff:127.0.0.1','2026-04-20 15:27:31'),(126,'user_e7dab160e50e00846c281c8c','LOGIN','AUTH','Admin impersonated Brand User: anjan@gmail.com (Brand ID: 16)','::1','2026-04-20 15:31:02'),(127,'user_e7dab160e50e00846c281c8c','LOGIN','AUTH','Admin impersonated Brand User: anjan@gmail.com (Brand ID: 16)','::1','2026-04-20 15:31:14'),(128,'user_e7dab160e50e00846c281c8c','CREATE','BRAND','Brand \"Brand B\" created (ID: 17)','::1','2026-04-20 15:35:07'),(129,NULL,'LOGOUT','AUTH','User \"anjan_gmail.com\" logged out','::ffff:127.0.0.1','2026-04-20 15:35:15'),(130,'user_e7dab160e50e00846c281c8c','UPDATE','BILLING','Subscription ID 4 updated','::ffff:127.0.0.1','2026-04-20 15:46:12'),(131,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 27 manually assigned to Brand ID 16','::1','2026-04-20 17:11:51'),(132,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 16 updated','::1','2026-04-20 17:55:24'),(133,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 17 updated','::ffff:127.0.0.1','2026-04-20 17:56:26'),(134,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 16 updated','::1','2026-04-20 20:20:31'),(135,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 16 updated','::ffff:127.0.0.1','2026-04-20 20:20:51'),(136,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 16 updated','::ffff:127.0.0.1','2026-04-20 21:18:16'),(137,'user_e7dab160e50e00846c281c8c','UPDATE','BRAND','Brand ID 16 updated','::ffff:127.0.0.1','2026-04-20 21:18:26'),(138,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 3 on Display 6 (mediaId: 29)','::ffff:127.0.0.1','2026-04-20 22:10:14'),(139,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 5 on Display 6 (mediaId: 30)','::1','2026-04-20 22:10:29'),(140,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 30 linked to Brand ID 17 on Display 6','::1','2026-04-20 22:10:34'),(141,'user_e7dab160e50e00846c281c8c','CREATE','BILLING','Subscription created for Brand ID 17 (Plan: test)','::1','2026-04-20 22:11:20'),(142,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 12 on Display 6 assigned to Brand ID 16','::1','2026-04-20 22:11:36'),(143,'user_e7dab160e50e00846c281c8c','UNASSIGN','SLOT','Slot 12 on Display 6 unassigned','::ffff:127.0.0.1','2026-04-20 22:11:38'),(144,'user_e7dab160e50e00846c281c8c','CREATE','BRAND','Brand \"Brand b\" created (ID: 18)','::1','2026-04-20 22:12:42'),(145,'user_e7dab160e50e00846c281c8c','CREATE','BILLING','Subscription created for Brand ID 18 (Plan: trr)','::1','2026-04-20 22:13:00'),(146,'user_e7dab160e50e00846c281c8c','UPDATE','BILLING','Subscription ID 6 updated','::1','2026-04-20 22:13:09'),(147,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 4 on Display 6 assigned to Brand ID 18','::ffff:127.0.0.1','2026-04-20 22:20:58'),(148,'user_e7dab160e50e00846c281c8c','ASSIGN','SLOT','Slot 5 on Display 6 assigned to Brand ID 18','::ffff:127.0.0.1','2026-04-20 22:21:00'),(149,NULL,'LOGOUT','AUTH','User \"anjan_gmail.com\" logged out','::1','2026-04-20 22:22:17'),(150,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 19 updated','::ffff:127.0.0.1','2026-04-20 22:24:38'),(151,'user_e7dab160e50e00846c281c8c','UPDATE','SCREEN','Screen ID 19 updated','::1','2026-04-20 22:24:50'),(152,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"Screen 1\" registered via code (Xibo ID: undefined)','::1','2026-04-20 22:26:49'),(153,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"test\" registered via code (Xibo ID: undefined)','::ffff:127.0.0.1','2026-04-20 22:32:38'),(154,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"SM-T735-unknown\" registered via code (Xibo ID: 7)','::1','2026-04-20 22:51:03'),(155,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"SM-T735-unknown\" (ID: 20) deleted','::ffff:127.0.0.1','2026-04-20 22:52:02'),(156,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"SM-T735-unknown\" (ID: 21) deleted','::1','2026-04-20 22:52:09'),(157,'user_e7dab160e50e00846c281c8c','DELETE','SCREEN','Screen \"SM-T735-unknown\" (ID: 22) deleted','::ffff:127.0.0.1','2026-04-20 22:52:24'),(158,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"SM-T735-unknown\" registered via code (Xibo ID: 8)','::1','2026-04-20 22:53:43'),(159,'user_e7dab160e50e00846c281c8c','CREATE','SCREEN','Xibo Display \"CPH2569-unknown\" registered via code (Xibo ID: 6)','::ffff:127.0.0.1','2026-04-20 22:53:55'),(160,'user_e7dab160e50e00846c281c8c','UPLOAD','SLOT','Media uploaded and added to Slot 1 on Display 8 (mediaId: 31)','::ffff:127.0.0.1','2026-04-20 22:54:59'),(161,'user_e7dab160e50e00846c281c8c','ASSIGN','CREATIVE','Media ID 31 linked to Brand ID 18 on Display 8','::ffff:127.0.0.1','2026-04-20 22:55:01'),(162,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-20 22:55:56'),(163,NULL,'LOGOUT','AUTH','User \"admin\" logged out','::ffff:127.0.0.1','2026-04-20 22:57:54');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  `extra_fields` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `custom_fields` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (16,'Brand A','Tech','Anjan Kumar','anjan@gmail.com','09885147427','Active','{}','2026-04-20 15:25:18','[{\"key\": \"gdt\", \"value\": \"234567\"}, {\"key\": \"df34567\", \"value\": \"2345678\"}]'),(18,'Brand b','Tech','Anjan Kumar','97@gmail.com','09885147427','Active','{}','2026-04-20 22:12:42','[{\"key\": \"fgh\", \"value\": \"12345678\"}]');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) NOT NULL,
  `brand_id` int DEFAULT NULL,
  `screen_id` varchar(50) DEFAULT NULL,
  `slot_number` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `creative_id` int DEFAULT NULL,
  `status` enum('Active','Paused','Stopped','Ended') DEFAULT 'Active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `campaigns_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_media_stats`
--

DROP TABLE IF EXISTS `daily_media_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_media_stats` (
  `mediaId` int NOT NULL,
  `displayId` int NOT NULL,
  `date` date NOT NULL,
  `count` int DEFAULT '0',
  PRIMARY KEY (`mediaId`,`displayId`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_media_stats`
--

LOCK TABLES `daily_media_stats` WRITE;
/*!40000 ALTER TABLE `daily_media_stats` DISABLE KEYS */;
INSERT INTO `daily_media_stats` VALUES (1,1,'2026-04-14',102),(1,1,'2026-04-15',148),(1,1,'2026-04-16',148),(1,3,'2026-04-15',170),(1,3,'2026-04-16',170),(2,1,'2026-04-14',87),(2,1,'2026-04-15',131),(2,1,'2026-04-16',131),(2,3,'2026-04-15',159),(2,3,'2026-04-16',159),(4,2,'2026-04-15',18),(4,2,'2026-04-16',18),(21,3,'2026-04-15',173),(21,3,'2026-04-16',173),(21,3,'2026-04-18',182),(21,3,'2026-04-19',182),(21,3,'2026-04-20',97),(22,3,'2026-04-15',176),(22,3,'2026-04-16',176),(22,3,'2026-04-18',188),(22,3,'2026-04-19',188),(22,3,'2026-04-20',181),(23,3,'2026-04-15',72),(23,3,'2026-04-16',72),(23,3,'2026-04-18',173),(23,3,'2026-04-19',173),(23,3,'2026-04-20',95),(24,3,'2026-04-18',45),(24,3,'2026-04-19',114),(24,3,'2026-04-20',114),(25,3,'2026-04-18',52),(25,3,'2026-04-19',120),(25,3,'2026-04-20',120),(26,3,'2026-04-18',42),(26,3,'2026-04-19',108),(26,3,'2026-04-20',108),(27,6,'2026-04-20',92),(27,6,'2026-04-21',92),(27,6,'2026-04-22',54),(28,6,'2026-04-20',90),(28,6,'2026-04-21',90),(28,6,'2026-04-22',53),(29,6,'2026-04-21',42),(29,6,'2026-04-22',42),(30,6,'2026-04-21',42),(30,6,'2026-04-22',42);
/*!40000 ALTER TABLE `daily_media_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `brand_id` int DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  `due_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_brands`
--

DROP TABLE IF EXISTS `media_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_brands` (
  `mediaId` int NOT NULL,
  `brand_id` int DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Approved',
  PRIMARY KEY (`mediaId`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `media_brands_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_brands`
--

LOCK TABLES `media_brands` WRITE;
/*!40000 ALTER TABLE `media_brands` DISABLE KEYS */;
INSERT INTO `media_brands` VALUES (27,16,'Approved'),(28,18,'Approved'),(29,16,'Approved'),(30,18,'Approved'),(31,18,'Approved');
/*!40000 ALTER TABLE `media_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_payouts`
--

DROP TABLE IF EXISTS `partner_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partner_payouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `partner_id` int DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('Pending','Paid') DEFAULT 'Pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `partner_id` (`partner_id`),
  CONSTRAINT `partner_payouts_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_payouts`
--

LOCK TABLES `partner_payouts` WRITE;
/*!40000 ALTER TABLE `partner_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_xibo_credentials`
--

DROP TABLE IF EXISTS `partner_xibo_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partner_xibo_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `partner_id` int NOT NULL,
  `xibo_base_url` varchar(512) NOT NULL,
  `client_id` varchar(255) NOT NULL,
  `client_secret` varchar(255) NOT NULL,
  `access_token` text,
  `token_expires_at` datetime DEFAULT NULL,
  `provision_status` enum('pending','provisioning','active','error') DEFAULT 'pending',
  `provision_error` text,
  `provision_log` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partner_id` (`partner_id`),
  CONSTRAINT `partner_xibo_credentials_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_xibo_credentials`
--

LOCK TABLES `partner_xibo_credentials` WRITE;
/*!40000 ALTER TABLE `partner_xibo_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner_xibo_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_xibo_resources`
--

DROP TABLE IF EXISTS `partner_xibo_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partner_xibo_resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `partner_id` int NOT NULL,
  `resource_type` enum('folder','display_group','layout','playlist','campaign','schedule') NOT NULL,
  `xibo_resource_id` int NOT NULL,
  `xibo_resource_name` varchar(512) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_partner_resource` (`partner_id`,`resource_type`),
  CONSTRAINT `partner_xibo_resources_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_xibo_resources`
--

LOCK TABLES `partner_xibo_resources` WRITE;
/*!40000 ALTER TABLE `partner_xibo_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner_xibo_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text,
  `status` varchar(100) DEFAULT 'Pending',
  `revenue_share_percentage` int DEFAULT '50',
  `xibo_provision_status` varchar(50) DEFAULT 'not_started',
  `xibo_folder_id` int DEFAULT NULL,
  `xibo_display_group_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'Anjan Kumar','test','Hyderabad','test@test.com','09885147427','4-128/15','Active',50,'not_started',NULL,NULL,'2026-04-18 11:01:48');
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `permissions` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screen_partners`
--

DROP TABLE IF EXISTS `screen_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `screen_partners` (
  `displayId` int NOT NULL,
  `partner_id` int DEFAULT NULL,
  PRIMARY KEY (`displayId`),
  KEY `partner_id` (`partner_id`),
  CONSTRAINT `screen_partners_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screen_partners`
--

LOCK TABLES `screen_partners` WRITE;
/*!40000 ALTER TABLE `screen_partners` DISABLE KEYS */;
/*!40000 ALTER TABLE `screen_partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screens`
--

DROP TABLE IF EXISTS `screens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `screens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `screen_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` text,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `location_source` varchar(100) DEFAULT 'manual',
  `timezone` varchar(255) DEFAULT 'Asia/Kolkata',
  `partner_id` int DEFAULT NULL,
  `xibo_display_id` int DEFAULT NULL,
  `xibo_display_group_id` int DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  `orientation` varchar(50) DEFAULT 'Landscape',
  `resolution` varchar(50) DEFAULT NULL,
  `client_address` varchar(100) DEFAULT NULL,
  `mac_address` varchar(100) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `device_model` varchar(255) DEFAULT NULL,
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `partner_id` (`partner_id`),
  CONSTRAINT `screens_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screens`
--

LOCK TABLES `screens` WRITE;
/*!40000 ALTER TABLE `screens` DISABLE KEYS */;
INSERT INTO `screens` VALUES (19,'SIG-6','CPH2569-unknown','Hyderabad','4-128/15',17.3387075,78.3821582,'GPS',NULL,1,6,NULL,'Offline','landscape','2412x1080','122.177.244.159','','OnePlus','CPH2569','','2026-04-19 18:49:00','2026-04-20 23:03:24'),(23,'SIG-8','SM-T735-unknown',NULL,'Hyderabad, Telangana, India',17.33828304,78.38218317,'GPS','Asia/Kolkata',NULL,8,NULL,'Offline','landscape','2560x1600','122.177.244.159','','samsung','SM-T735',NULL,'2026-04-20 22:53:43','2026-04-20 23:03:24');
/*!40000 ALTER TABLE `screens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` varchar(255) NOT NULL,
  `userId` varchar(255) NOT NULL,
  `token` text NOT NULL,
  `expiresAt` datetime NOT NULL,
  `ipAddress` varchar(255) DEFAULT NULL,
  `userAgent` text,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session_ibfk_1` (`userId`),
  CONSTRAINT `session_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('1NBxFNw9KEVAalPBGmQY2u5kqqfvxbcW','user_e7dab160e50e00846c281c8c','SzMj1dXZ5CQSmt6dn0ybdCytPjpnFuZ4','2026-04-27 17:09:41','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 17:09:41','2026-04-20 17:09:41'),('1w77Am6JqnWd3QoUUWIxBGsv0N7l87sT','user_10a539f695c89197a048b827','1bXyvqkGrAbU2ElbvFx7kCXIR9LppKzJ','2026-04-26 12:12:37','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 12:12:37','2026-04-19 12:12:37'),('4ntVx2Ujx27Z8zyxVRGupndhSpO17ZXc','user_e7dab160e50e00846c281c8c','NFsSEMkPkoddZg3XPxGLIG11nnLvqHnn','2026-04-27 15:31:27','127.0.0.1','curl/8.5.0','2026-04-20 15:31:27','2026-04-20 15:31:27'),('9zjdyuNzTnJ5s2HsLjKvb4ZHJpyPiNPp','gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','13NsAXledPKzgmCBdNTGldOt0rKH5Lrc','2026-04-27 22:56:34','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 22:56:34','2026-04-20 22:56:34'),('ae3cwtuAAATqvFogLuDRyTdkDYVScj9i','user_e7dab160e50e00846c281c8c','d8B0VL0QMdwR8fGj5MFedoxlpTfiVnfG','2026-04-25 22:37:31','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 22:37:31','2026-04-18 22:37:31'),('CsDM9XCxNUmmqhyT4CoiGmUuYOaovQRc','user_e7dab160e50e00846c281c8c','lKrdoIW5gdUwqxsTRUCUL1M2jYERaf9E','2026-04-25 21:25:13','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:25:13','2026-04-18 21:25:13'),('dCQW6h5z0BktulKb3E4LZy2UyDIvwj3P','user_e7dab160e50e00846c281c8c','Kp022P3jXb0zXHP1n7gmT9ZULJHIindB','2026-04-26 11:24:14','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 11:24:14','2026-04-19 11:24:14'),('DWGhj5SybW4iBGsyhUQj5oMqR0V87QqZ','user_e7dab160e50e00846c281c8c','8qUXpIzZi0t3BTpZgxeBB36yKvBOvoP6','2026-04-27 21:17:59','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 21:17:59','2026-04-20 21:17:59'),('G592temLUPqdmnN90qPaBVCYhb72NeTZ','user_10a539f695c89197a048b827','CCLTGJNJHK1JEGRcaq9NFABWuhjkfKav','2026-04-25 21:21:05','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:21:05','2026-04-18 21:21:05'),('gU09iVRYvg98AAvnDY3sAtYXSj2tjmuc','user_ed5c13476458e276304adaf2','KF1M2t3UbK4cSttrDw8d5r0J07ENZVsE','2026-04-25 16:28:03','','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 16:28:03','2026-04-18 16:28:03'),('hlPcnojY0bP6yRBGMypQvShYnUsAVFo9','user_ed5c13476458e276304adaf2','ROi1Tgq85jB8uYRr0s9e8HrRds8Hm9ux','2026-04-25 16:44:58','','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 16:44:58','2026-04-18 16:44:58'),('Ht7jsYHKLdJMtBOiKGR7XkvYSV7JBObS','user_ed5c13476458e276304adaf2','9yUfR4IeZWGWez5qKSxgacXKNPYU8LMw','2026-04-25 17:00:50','','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 17:00:50','2026-04-18 17:00:50'),('IGMcHYSECwn9m9E6qKDAMqmMZ8si4bDp','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','9Fqlr6SpacglfBnNWHGXhRmx6Y5hQUKS','2026-04-27 15:25:19','','','2026-04-20 15:25:19','2026-04-20 15:25:19'),('IHEqwWbm5sHZAmX0yuhUKsTd70ozJqYH','3aWsjPSEhfh9GZDlYooNUImsJaKQcYg8','i8DmDaMybBLpiSf2Xnm9Ukpd5YiAqqGf','2026-04-27 15:35:23','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 15:35:23','2026-04-20 15:35:23'),('kkAdvtY1CVsnWt2kphS1FCnkVeLFWgmW','gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','MzNbW6gx0IZcSKUveVOQAihMub7bqZBl','2026-04-27 22:22:33','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 22:22:33','2026-04-20 22:22:33'),('KMXvjvttqYXArJEBFQUA8wSnMlo97xK1','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','tP3FTP19D25XjEHpitxenAOt462IwmT7','2026-04-27 17:10:13','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 17:10:13','2026-04-20 17:10:13'),('Koeq0MaMkcOYSnZTvdMxSFwuu3NJjtGt','user_e7dab160e50e00846c281c8c','hrDuJbRQdRm11H3MhnPM4X72LWDQNYli','2026-04-26 18:54:01','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 18:54:01','2026-04-19 18:54:01'),('kXE5c2VXsqROyfFroGWFQ8X91YYJACIt','user_e7dab160e50e00846c281c8c','jimW1Q107tCPNaBFfNsczvppzWtWXUZb','2026-04-27 15:31:02','127.0.0.1','curl/8.5.0','2026-04-20 15:31:02','2026-04-20 15:31:02'),('L0f9FwIeg9hq3uDgpXhQxKMwXpSrp8x8','user_e7dab160e50e00846c281c8c','D9ICdXH6XnIhQwRHMqOaAc9nnW2GT2r8','2026-04-27 15:21:52','127.0.0.1','curl/8.5.0','2026-04-20 15:21:52','2026-04-20 15:21:52'),('L6i8RtoEzJlTS7vrnLj6846HYdoJ1HRV','user_e7dab160e50e00846c281c8c','W8FuFZcdWjrR3tcxn59tRDG93NkrzLrI','2026-04-26 14:01:17','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 14:01:17','2026-04-19 14:01:17'),('LDoIBXK2nxEpSJvRtGaCP2v7uT1l3HWE','user_e7dab160e50e00846c281c8c','mn6iLFnKDnk5G6TbHGrT6DV9cLE1yKdP','2026-04-25 21:38:42','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:38:42','2026-04-18 21:38:42'),('m3Dt6yhIUOojlX446nRpnRG2bZknrPog','user_e7dab160e50e00846c281c8c','7ImL6iCh2O7FORIGFg1KZk3rHoTcf17k','2026-04-26 10:44:21','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 10:44:21','2026-04-19 10:44:21'),('m8iod8c4GK8xpSLZ8lfdPhcEd0o9sLLw','user_e7dab160e50e00846c281c8c','CMwaFDdwYwYlKOBRe5DSOmHPuAE2yHdf','2026-04-25 21:15:43','127.0.0.1','curl/8.5.0','2026-04-18 21:15:43','2026-04-18 21:15:43'),('m9AQgDCiph1tXhxwgPGIJta31t51k6b6','user_e7dab160e50e00846c281c8c','p63ApnSQnMuf1Hn5JkYDKfjsi2W40I00','2026-04-26 12:14:32','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 12:14:32','2026-04-19 12:14:32'),('NKnBSd3CAuYJDbY3LXCbjEvDQ2gXi7oZ','user_e7dab160e50e00846c281c8c','fduUUWiffU2BSw1KUm8UMmmOhG06nMIT','2026-04-26 18:52:46','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 18:52:46','2026-04-19 18:52:46'),('qbIjKULWDQvpGYNt87I9RkmnMin9uB4o','user_e7dab160e50e00846c281c8c','hsCkWGREltnv26DIk5ZAhC2FSKBThh0D','2026-04-25 21:18:01','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:18:01','2026-04-18 21:18:01'),('qM1cjJtAaYqTnni5mimZN4av7KMh0YLP','3aWsjPSEhfh9GZDlYooNUImsJaKQcYg8','eUwSwMp9mdng9faYVh5ui3wUvgNpeiWZ','2026-04-27 15:35:08','','','2026-04-20 15:35:08','2026-04-20 15:35:08'),('QSaOsazFQDhM8f3mcnRPlSVsu463oAjR','gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','KbG3XRoJs1kZ4pSx7pB3rN5fhJZ4RsDR','2026-04-27 22:12:42','','','2026-04-20 22:12:42','2026-04-20 22:12:42'),('S7wBdhEfdg6hlvj75kmCgQRDHKBum094','user_e7dab160e50e00846c281c8c','BigUM8DeA7VrCq7cGrkpQ7l0OvBGtXw7','2026-04-27 21:55:09','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 21:55:09','2026-04-20 21:55:09'),('sess_72d43612599c6bb7bf444bc8','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','tok_0db459e19a586752048cfd90','2026-04-20 17:31:02','::1','curl/8.5.0','2026-04-20 15:31:02','2026-04-20 15:31:02'),('sess_abf1aabfd201b99d59a62e94','user_ed5c13476458e276304adaf2','tok_6f48843d2faa11655f716e28','2026-04-20 17:21:53','::1','curl/8.5.0','2026-04-20 15:21:52','2026-04-20 15:21:52'),('sess_c69c63a37da7d4ce14d75c25','PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','tok_1da5b4a3f5ff9711f1e2afbb','2026-04-20 17:31:14','::1','curl/8.5.0','2026-04-20 15:31:14','2026-04-20 15:31:14'),('TMcKsXHhoKkDv8OHiTsTqTfwxpuSVwCg','user_ed5c13476458e276304adaf2','W85nrFdaIh9dxGQqO3n7o7i6UL5a10DI','2026-04-26 11:49:36','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 11:49:36','2026-04-19 11:49:36'),('uUqGH0J3jllmrUTCi3wjPGzCVcv6qq2b','user_ed5c13476458e276304adaf2','kmPZirAVuzJRjsCFNDHVw6NucccoV5lk','2026-04-25 20:08:06','','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 20:08:06','2026-04-18 20:08:06'),('vOnxGV1WlH6Ysdrv5QwvpayI1Yvdw6y1','user_10a539f695c89197a048b827','3IdXcskUWbS3UOXsAPUArTY6sEeZDHuh','2026-04-26 13:59:02','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-19 13:59:02','2026-04-19 13:59:02'),('WIASu4bX0O3xgRXX5vTuWL0TTcU3xydB','user_e7dab160e50e00846c281c8c','yNfybGOsjjQIHXi8sgW7mJjLtGcpZ01t','2026-04-25 22:07:10','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 22:07:10','2026-04-18 22:07:10'),('XMABDFSbUBcfvNL8ieESeowNFrOb3huA','user_e7dab160e50e00846c281c8c','gxWBhYPv1FceCLecjq7KgdqGIZkigCpl','2026-04-25 22:51:37','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 22:51:37','2026-04-18 22:51:37'),('xpcBBFpGyF8WfEZbN10fsVaWQ4Lw6nym','user_e7dab160e50e00846c281c8c','F7sUA4dw14o0gkj6s1hCp39I9ZfIo51e','2026-04-25 21:15:19','','','2026-04-18 21:15:19','2026-04-18 21:15:19'),('Xwvy0aJXA1fI6feaPU8nKwIqM5GhH133','user_ed5c13476458e276304adaf2','tHd6GLllZzsdWcPOnNwLF68hGqpRXADU','2026-04-25 21:20:25','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:20:25','2026-04-18 21:20:25'),('y1FVQdjKcOQQSFK9ZFYjGxtME1TGortY','user_e7dab160e50e00846c281c8c','MGuNKuzTtdxeBLp6JzQn3G4RDdFth2xG','2026-04-25 21:30:55','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 21:30:55','2026-04-18 21:30:55'),('yTMFKtxg5l2EYxjYQiOhb1cuNgfUH22U','user_e7dab160e50e00846c281c8c','0NSVtmzdK2HgPqew8OkasM3IIipImOJL','2026-04-25 22:20:35','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-18 22:20:35','2026-04-18 22:20:35'),('yVtEPCSqdw5DxzYukFAOliqyQeKycpHd','user_e7dab160e50e00846c281c8c','27Jja9kDeWhcxNNS1cehAbGheMTNaV9P','2026-04-27 14:44:52','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-04-20 14:44:52','2026-04-20 14:44:52'),('zcZ3DIr2ewdK9thlf9D8SWovhjjTDvkO','user_e7dab160e50e00846c281c8c','azpkGWqwyEKl2EWLEze5rFg6C72aePdO','2026-04-27 15:31:14','127.0.0.1','curl/8.5.0','2026-04-20 15:31:14','2026-04-20 15:31:14');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slots`
--

DROP TABLE IF EXISTS `slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `displayId` int NOT NULL,
  `slot_number` int NOT NULL,
  `brand_id` int DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Available',
  `playlist_id` int DEFAULT NULL,
  `xibo_widget_id` int DEFAULT NULL,
  `mediaId` int DEFAULT NULL,
  `duration` int DEFAULT '13',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `subscription_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `creative_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_display_slot` (`displayId`,`slot_number`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `slots_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=387 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slots`
--

LOCK TABLES `slots` WRITE;
/*!40000 ALTER TABLE `slots` DISABLE KEYS */;
INSERT INTO `slots` VALUES (283,6,1,16,'Active',NULL,NULL,NULL,13,'2026-04-20 15:26:31',4,NULL,NULL,NULL),(284,6,2,16,'Active',NULL,NULL,27,13,'2026-04-20 15:27:27',4,NULL,NULL,NULL),(285,6,4,18,'Active',NULL,NULL,28,13,'2026-04-20 22:20:58',6,NULL,NULL,NULL),(286,6,3,16,'Assigned',NULL,NULL,29,13,'2026-04-20 22:10:12',4,NULL,NULL,NULL),(287,6,5,18,'Active',NULL,NULL,30,13,'2026-04-20 22:21:00',6,NULL,NULL,NULL),(288,6,6,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(289,6,7,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(290,6,8,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(291,6,9,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(292,6,10,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(293,6,11,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(294,6,12,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:11:38',NULL,NULL,NULL,NULL),(295,6,13,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 15:24:08',NULL,NULL,NULL,NULL),(296,6,14,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(297,6,15,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(298,6,16,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(299,6,17,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(300,6,18,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(301,6,20,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(302,6,19,NULL,'Available',NULL,NULL,NULL,13,'2026-04-19 18:48:09',NULL,NULL,NULL,NULL),(366,8,1,18,'Assigned',NULL,NULL,31,13,'2026-04-20 22:55:01',NULL,NULL,NULL,NULL),(367,8,2,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(368,8,3,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(369,8,4,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(370,8,5,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(371,8,7,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(372,8,8,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(373,8,10,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(374,8,9,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(375,8,6,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(376,8,11,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(377,8,12,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(378,8,13,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(379,8,14,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(380,8,15,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(381,8,16,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(382,8,17,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(383,8,18,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(384,8,19,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL),(385,8,20,NULL,'Available',NULL,NULL,NULL,13,'2026-04-20 22:53:43',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_id` int NOT NULL,
  `plan_name` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `screens_included` int NOT NULL DEFAULT '1',
  `slots_included` int NOT NULL DEFAULT '1',
  `cities` text,
  `payment_status` enum('Pending','Paid','Overdue') DEFAULT 'Pending',
  `status` enum('Draft','Awaiting Payment','Active','Paused','Expired','Cancelled') DEFAULT 'Draft',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (4,16,'test','2026-04-13','2026-04-29',1,5,'hyd','Paid','Active','','2026-04-20 15:26:27','2026-04-20 15:46:12'),(6,18,'trr','2026-04-20','2026-04-25',1,4,'hh','Paid','Active','','2026-04-20 22:13:00','2026-04-20 22:13:09');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT '',
  `username` varchar(255) NOT NULL,
  `displayUsername` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emailVerified` tinyint(1) DEFAULT '0',
  `image` text,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT 'Admin',
  `brand_id` int DEFAULT NULL,
  `partner_id` int DEFAULT NULL,
  `force_password_reset` tinyint(1) DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `brand_id` (`brand_id`),
  KEY `partner_id` (`partner_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('3aWsjPSEhfh9GZDlYooNUImsJaKQcYg8','test','test1_gmail.com','test1_gmail.com',NULL,'test1@gmail.com',0,NULL,NULL,'Brand',NULL,NULL,0,'2026-04-20 15:35:08','2026-04-20 22:12:19'),('gIk47srNAQ1dmLdkQdE1SfnDgaQKSidS','Anjan Kumar','97_gmail.com','97_gmail.com',NULL,'97@gmail.com',0,NULL,NULL,'Brand',18,NULL,0,'2026-04-20 22:12:42','2026-04-20 22:12:42'),('PBP7SL4IseSFqH3P2AeRqW3zoKaVqKac','Anjan Kumar','anjan_gmail.com','anjan_gmail.com',NULL,'anjan@gmail.com',0,NULL,NULL,'Brand',16,NULL,0,'2026-04-20 15:25:18','2026-04-20 15:25:18'),('user_10a539f695c89197a048b827','','test@test.com',NULL,'250a89e19ac111b72ba539a07a20b18a:a8b8ec32df669017a0b89476be04f9b8d51c10c19acc5648da7e12593e34db2cd90d212f6767517e7445105be921d7a86c7f3a7e1322759747a978934dfba309','test@test.com',0,NULL,NULL,'Partner',NULL,1,1,'2026-04-18 21:20:58','2026-04-19 12:12:29'),('user_e7dab160e50e00846c281c8c','','admin',NULL,'9fa6ffe6ff60070be57726bde442758d:2bc0b2e65fef0344284bc55c42e66113a128e2174229272c0e5aecaab9f9d7028b2a500bc6eed00c90301c5028181d2300a6d4acfe906f8ca61a5f3b993625db','admin@signtral.com',0,NULL,NULL,'SuperAdmin',NULL,NULL,0,'2026-04-18 21:13:24','2026-04-18 21:13:26'),('user_ed5c13476458e276304adaf2','','test@gmail.com',NULL,'4b32fc8a35e55e944424806b2f6b2060:620372075f63df357cbfba72662798ce522735fbd77763e5f30f7d836ad40c1ed5a932f9711de4291a30c395e5079bba8466da81c43c40c015c86b8f4cd2325a','test@gmail.com',0,NULL,NULL,'Brand',NULL,NULL,0,'2026-04-18 16:27:39','2026-04-20 15:25:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification`
--

DROP TABLE IF EXISTS `verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification` (
  `id` varchar(255) NOT NULL,
  `identifier` text NOT NULL,
  `value` text NOT NULL,
  `expiresAt` datetime NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification`
--

LOCK TABLES `verification` WRITE;
/*!40000 ALTER TABLE `verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-20 23:03:42
